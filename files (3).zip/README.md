# RailCloud — Railway Ticket Booking on AWS (Architecture Simulation)

## ⚠️ What this project is

This is a **single-page frontend simulation** of a railway ticket booking system designed to demonstrate how such a system would be architected on AWS. It runs entirely in the browser — **no AWS account, backend, or real infrastructure is provisioned**. Every "AWS service call" you see in the live console panel is a scripted log line that mimics what a real request/response trace would look like.

It was built as a learning/demo artifact for an AWS Cloud Computing course project, to visualize:
- Which AWS services fit into each stage of a booking workflow
- How those services would talk to each other (event flow, not just a static diagram)
- Realistic latency, caching, and failure-handling patterns (cache hit/miss, seat locking, hold timers, etc.)

If you're presenting this as coursework, be explicit with your instructor/reviewers that it's a **UI/architecture mockup**, not a deployed system.

## Live demo

Open `index.html` directly in a browser, or enable **GitHub Pages** for this repo (Settings → Pages → Deploy from branch → `main` → `/root`) to get a shareable link.

## Simulated booking flow

The app walks through 6 steps, each mapped to a stage of a real booking pipeline:

| Step | User action | Simulated AWS flow |
|---|---|---|
| 1. Search | Pick origin, destination, date | API Gateway → Lambda (`SearchTrainsFunction`) → ElastiCache (Redis) cache check → DynamoDB query on cache miss → CloudWatch/X-Ray tracing |
| 2. Results | Browse trains & fare classes | Rendered from the search response |
| 3. Seats | Pick a seat, lock it | SQS buffers the lock request → DynamoDB seat status updated to `LOCKED` → EventBridge schedules an auto-release if payment doesn't complete in time |
| 4. Passengers | Enter traveller + contact details | Cognito (signed-in) or a scoped guest identity |
| 5. Payment | Submit card/UPI/net-banking details | Step Functions orchestrates the workflow: Secrets Manager (gateway key) → KMS (envelope-encrypts the payload) → Lambda (`ProcessPaymentFunction`) → RDS Aurora (ACID insert into `bookings`) → DynamoDB Streams flips seat status to `BOOKED` |
| 6. Confirmation | E-ticket issued | SNS publishes `BookingConfirmed` → SES emails the e-ticket → S3 stores the ticket PDF → CloudFront serves it via signed URL |

## AWS services represented

| Service | Category | Role in this design |
|---|---|---|
| Route 53 | Edge | Resolves the app domain to the nearest edge location |
| AWS WAF | Edge | Inspects incoming requests for bots / SQL injection |
| CloudFront | Edge | CDN caching + TLS termination for the frontend |
| Amazon S3 | Edge / Storage | Hosts the static SPA build; stores generated e-tickets |
| Cognito | Auth | User pool sign-in and guest identity for unauthenticated bookings |
| IAM | Security | Least-privilege roles scoped to each function |
| API Gateway | API | Throttled REST endpoints in front of Lambda |
| Lambda | API | Stateless business-logic functions (search, payment, seat updates) |
| ElastiCache (Redis) | Data | Caches hot search results |
| DynamoDB | Data | Train schedule and seat inventory tables |
| SQS | Orchestration | Buffers booking spikes, serializes seat-lock requests |
| Step Functions | Orchestration | Orchestrates the multi-stage booking workflow |
| EventBridge | Orchestration | Scheduled rule to release unpaid seat holds |
| RDS Aurora | Data | ACID-compliant ledger for confirmed bookings and payments |
| KMS | Security | Envelope-encrypts payment data |
| Secrets Manager | Security | Rotates DB and payment-gateway credentials |
| SNS | Notifications | Fans out the `BookingConfirmed` event |
| SES | Notifications | Delivers the e-ticket email |
| CloudWatch | Operations | Metrics, logs, and alarms across every service |
| X-Ray | Operations | End-to-end distributed request tracing |

## Tech stack

- Plain HTML5 + CSS3 (no build step, no framework)
- Vanilla JavaScript for state management and rendering
- Google Fonts (Space Grotesk, Inter, JetBrains Mono)

## What would be needed to make this a real deployment

This repo only covers the frontend/UI layer. A working version would additionally need:
- IaC (Terraform / AWS CDK / CloudFormation) defining the actual resources listed above
- Real Lambda function code for search, seat locking, and payment processing
- A DynamoDB schema (train schedule table + seat inventory table with a GSI on route/date)
- An RDS Aurora instance with a `bookings` table and proper migrations
- A Step Functions state machine definition for the payment workflow
- Cognito user pool configuration and IAM roles per the principle of least privilege
- A CI/CD pipeline (e.g., GitHub Actions) to deploy both infrastructure and frontend

## Disclaimer

This is a simulated ticket-booking experience for demonstration purposes only. No real payments are processed and no personal data is transmitted to AWS or any third party.
